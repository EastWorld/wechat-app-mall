const app = getApp()

Page({
	data: {
		userInfo: {},		
	},
	onLoad() {
    this.getUserInfo();
    this.setData({
      version: app.globalData.version
    });
	},	
  getUserInfo: function (cb) {
      var that = this
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.setData({
                userInfo: res.userInfo
              });
            }
          })
        }
      })
  },
  ToMiniProgram: function () {
    var that = this;
    console.log('ToMiniProgram');
    wx.navigateToMiniProgram({
      appId: '填写你要跳转的APPID',
      path: '',
      extraData: {
        foo: 'bar'
      },
      envVersion: 'release',
      success(res) {
        // 打开成功
      }
    })
  },
  aboutUs : function () {
    wx.showModal({
      title: '关于我们',
      content: '本系统基于开源小程序商城系统 https://github.com/EastWorld/wechat-app-mall 搭建，祝大家使用愉快！',
      showCancel:false
    })
  }
})