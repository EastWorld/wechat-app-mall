//index.js
//获取应用实例
var app = getApp()

Page({
  data: {
    userInfo: {},
  },
  onLoad: function () {
    var that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })
    })
  },
  onPullDownRefresh() {
  },
  //头像右侧按钮，未设置
  gouwuche: function () {
    wx.navigateTo({
      url: ''
    });
  },
  myaddress: function () {
    wx.navigateTo({
      url: '/pages/select-address/index'
  });
},
  myorder: function () {
    wx.navigateTo({
      url: '/pages/order-list/index',
    })
  },
 
  ToMiniProgram: function () {
    var that = this;
    console.log('ToMiniProgram');
    wx.navigateToMiniProgram({
      appId: '同主体appid',
      path: '',
      extraData: {
        foo: 'bar'
      },
      envVersion: 'release',
      success(res) {
        // 打开成功
      }
    })
  },
  onShareAppMessage: function () {
    var pageRouter = this.page_router,
      pagePath = '/pages/' + pageRouter + '/' + pageRouter;

    // 统计用户分享APP
    appInstance.countUserShareApp();

    pagePath += this.dataId ? '?detail=' + this.dataId : '';
    return {
      title: appInstance.getAppTitle() || 'XXXX',
      desc: appInstance.getAppDescription() || 'XXXX提供技术支持',
      path: pagePath
    }
  }
    
    
    
})